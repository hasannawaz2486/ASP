# Assignment-Submission-Portal
Assignment  Submission Portal is django project where a student can upload his assignments.
