from django.contrib import messages, auth
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.views.generic import CreateView, FormView, RedirectView, UpdateView
from django.http import Http404

from .forms import *
from .models import User

from django.urls import reverse_lazy
from .decorators import user_is_student, user_is_instructor
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
import crispy_forms as crispy

# adding


# from django.contrib.auth.forms import UserCreationForm
# from crispy_forms.helper import FormHelper
# from crispy_forms.layout import Layout, ButtonHolder, Submit




# from wx.lib.pubsub.core import kwargs
# ending

# STUDENT REGISTRATION VIEW
class RegisterStudentView(CreateView):
    model = User
    form_class = StudentRegistrationForm
    template_name = 'authentication/student/register.html'
    success_url = '/'
    
    # success_url = 'student/register'

    extra_context = {
        'title': 'Register'
    }

    def dispatch(self, request, *args, **kwargs):
        if self.request.user.is_authenticated:
            return HttpResponseRedirect(self.get_success_url())
        return super().dispatch(self.request, *args, **kwargs)

    def post(self, request, *args, **kwargs):

        form = self.form_class(data=request.POST)

        if form.is_valid():
            user = form.save(commit=False)
            password = form.cleaned_data.get("password1")
            user.set_password(password)
            user.save()
            return redirect('authentication:login')
        else:
            return render(request, 'authentication/student/register.html', {'form': form})


# STUDENT PROFILE EDIT VIEW
class EditStudentProfileView(UpdateView):
    model = User
    form_class = StudentProfileUpdateForm
    context_object_name = 'student'
    template_name = 'authentication/student/edit-profile.html'
    success_url = reverse_lazy('authentication:student-profile-update')

    @method_decorator(login_required(login_url=reverse_lazy('accounts:login')))
    @method_decorator(user_is_student)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(self.request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        try:
            self.object = self.get_object()
        except Http404:
            raise Http404("User doesn't exists")
        # context = self.get_context_data(object=self.object)
        return self.render_to_response(self.get_context_data())

    def get_object(self, queryset=None):
        obj = self.request.user
        print(obj)
        if obj is None:
            raise Http404("Patient doesn't exists")
        return obj


# REGISTER INSTRUCTOR VIEW
class RegisterInstructorView(CreateView):
    model = User
    form_class = InstructorRegistrationForm
    template_name = 'authentication/instructor/register.html'
    success_url = '/'

    extra_context = {
        'title': 'Register'
    }

    def dispatch(self, request, *args, **kwargs):
        if self.request.user.is_authenticated:
            return HttpResponseRedirect(self.get_success_url())
        return super().dispatch(self.request, *args, **kwargs)

    def post(self, request, *args, **kwargs):

        form = self.form_class(data=request.POST)



        if form.is_valid():
            user = form.save(commit=False)
            password = form.cleaned_data.get("password1")
            user.set_password(password)
            user.save()
            return redirect('authentication:login')
        else:
            return render(request, 'authentication/instructor/register.html', {'form': form})


# INSTRUCTOR PROFILE EDIT VIEW
class EditInstructorProfileView(UpdateView):
    model = User
    form_class = InstructorProfileUpdateForm
    context_object_name = 'instructor'
    template_name = 'authentication/instructor/edit-profile.html'
    success_url = reverse_lazy('authentication:instructor-profile-update')

    @method_decorator(login_required(login_url=reverse_lazy('authentication:login')))
    @method_decorator(user_is_instructor)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(self.request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        try:
            self.object = self.get_object()
        except Http404:
            raise Http404("User doesn't exists")
        # context = self.get_context_data(object=self.object)
        return self.render_to_response(self.get_context_data())

    def get_object(self, queryset=None):
        obj = self.request.user
        print(obj)
        if obj is None:
            raise Http404("Patient doesn't exists")
        return obj


# LOGIN VIEW FOR BOTH USER
class LoginView(FormView):
    success_url = '/'
    form_class = UserLoginForm
    template_name = 'authentication/login.html'

    extra_context = {
        'title': 'Login'
    }

    def dispatch(self, request, *args, **kwargs):
        if self.request.user.is_authenticated:
            return HttpResponseRedirect(self.get_success_url())
        return super().dispatch(self.request, *args, **kwargs)

    def get_success_url(self):
        if 'next' in self.request.GET and self.request.GET['next'] != '':
            return self.request.GET['next']
        else:
            return self.success_url

    def get_form_class(self):
        return self.form_class

    def form_valid(self, form):
        auth.login(self.request, form.get_user())
        return HttpResponseRedirect(self.get_success_url())

    def form_invalid(self, form):
        """If the form is invalid, render the invalid form."""
        return self.render_to_response(self.get_context_data(form=form))


# LOGOUT VIEW
class LogoutView(RedirectView):
    url = '/login'

    def get(self, request, *args, **kwargs):
        auth.logout(request)
        messages.success(request, 'You are now logged out')
        return super(LogoutView, self).get(request, *args, **kwargs)
